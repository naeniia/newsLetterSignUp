import React, { useContext } from "react";
import { useState } from "react";
import { get, useForm } from "react-hook-form";
import { AuthContext } from './AuthContext.jsx';
import { useEffect } from "react";
import List from './list';


function Form(props) {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors }
  } = useForm();

  const [theEmail, setTheEmail] = useState("");

  const [allGood, setAllGood] = useContext(AuthContext);

  const onSubmit = (data) => {
    const userEmail = data.emailAddress;
    setTheEmail(userEmail);
    console.log(theEmail);
    console.log(userEmail)
    if (!errors.emailAddress) {
     isAllGood();
    }
  }

  console.log(theEmail)
  
  function isAllGood(){
    setAllGood(true);
  }

    return (
        <div id="white">
          <div id="main">
            <h1>Stay updated!</h1>
            <p>Join 60,000+ product managers {theEmail} receiving monthly updates on:</p>
            <List />
            <div id="form">
             <form onSubmit={handleSubmit(onSubmit)}>
              <label>Email Address</label>
              {errors?.emailAddress?.type === "pattern" && (<p className="error">Valid email required</p>)}
              {errors?.emailAddress?.type === "required" && <p className="error">Valid email required</p>}
              <input 
              type="email" 
              placeholder="email@company.com"
              className={errors.emailAddress && "invalid"}
              {...register("emailAddress", {
                required: true,
                pattern: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
              })}></input>
              <button type="submit" onClick={() => props.handleClick(theEmail)}>Subscribe to monthly newsletter</button>
             </form>    
            </div>
          </div>
          <img src="./images/illustration-sign-up-desktop.svg" className="bimg"></img>
        </div>
    )
}

export default Form;