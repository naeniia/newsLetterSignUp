import React, { useContext } from "react";
import { AuthContext } from './AuthContext.jsx';

function ThankYou(props) {
    
    const [allGood, setAllGood] = useContext(AuthContext);

    function goBack() {
        setAllGood(false);
    }

    console.log(props)
    console.log(allGood)

    return(
        <div id="tinyw">
           <img src="./images/icon-success.svg"></img>
           <h1 className="tinyh1">Thanks for susbscribing!</h1> 
           <p>A confirmation email has been sent to {props.email}. Please open it and click the button inside to confirm your subscription.</p>
           <button onClick={goBack}>Dismiss message</button>    
        </div>
    )
}

export default ThankYou;