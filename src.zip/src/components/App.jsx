import React from 'react';
import { useState, useEffect } from 'react';
import { AuthContext } from './AuthContext.jsx';
import Form from './form';
import ThankYou from './thankYou';
import Footer from './footer';

function App(props) {
  const [allGood, setAllGood] = useState(false);

  const [finalEmail, setFinalEmail] = useState("(crying noises)");

  function getUserEmail(theEmail){
    setFinalEmail(theEmail);
    console.log(finalEmail);
  }

  console.log(allGood)

  return (
   <AuthContext.Provider value={[allGood, setAllGood]}>
    <div>
     {allGood ? <ThankYou email={finalEmail} /> : <Form handleClick={getUserEmail} />}
     <Footer />
   </div> 
   </AuthContext.Provider>
  )
}

export default App
